const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

class GitService {
  constructor(repoPath = '') {
    this.repoPath = repoPath;
  }

  setRepoPath(repoPath) {
    this.repoPath = repoPath;
  }

  execGit(args) {
    return new Promise((resolve, reject) => {
      if (!this.repoPath) {
        reject(new Error('未选择仓库目录'));
        return;
      }

      const options = {
        cwd: this.repoPath,
        encoding: 'utf8',
        maxBuffer: 1024 * 1024 * 5,
        env: {
          ...process.env,
          LANG: 'zh_CN.UTF-8',
          LC_ALL: 'zh_CN.UTF-8',
          GIT_TERMINAL_PROMPT: '0'
        }
      };

      exec(`git ${args}`, options, (error, stdout, stderr) => {
        if (error && !stdout) {
          reject(stderr || error.message);
        } else {
          resolve(stdout.trim());
        }
      });
    });
  }

  async isRepo() {
    try {
      await this.execGit('rev-parse --git-dir');
      return true;
    } catch {
      return false;
    }
  }

  async getStatus() {
    const output = await this.execGit('status --porcelain');
    const files = [];
    if (!output) return files;

    const lines = output.split('\n').filter(line => line.trim());

    for (const line of lines) {
      if (line.length < 3) continue;
      const status = line.substring(0, 2);
      const fileName = line.substring(3).trim();

      let fileStatus = 'untracked';
      let staged = false;

      const indexStatus = status[0];
      const workTreeStatus = status[1];

      if (indexStatus === 'M' || workTreeStatus === 'M') {
        fileStatus = 'modified';
      } else if (indexStatus === 'A' || workTreeStatus === 'A') {
        fileStatus = 'added';
      } else if (indexStatus === 'D' || workTreeStatus === 'D') {
        fileStatus = 'deleted';
      } else if (indexStatus === 'R') {
        fileStatus = 'renamed';
      } else if (indexStatus === '?' && workTreeStatus === '?') {
        fileStatus = 'untracked';
      }

      staged = indexStatus !== ' ' && indexStatus !== '?';

      files.push({
        name: fileName,
        status: fileStatus,
        staged: staged
      });
    }
    return files;
  }

  async getBranches() {
    const output = await this.execGit('branch -a');
    const branches = [];
    const lines = output.split('\n').filter(line => line.trim());

    for (const line of lines) {
      const isCurrent = line.startsWith('*');
      const rawName = line.replace(/^\*\s*/, '').trim();
      const isRemote = rawName.startsWith('remotes/');
      const name = isRemote ? rawName.replace('remotes/', '') : rawName;

      branches.push({
        name: name,
        isRemote: isRemote,
        isCurrent: isCurrent
      });
    }
    return branches;
  }

  async getCommits(branch = 'HEAD', count = 50) {
    const format = '%H|%s|%an|%ad|%D';
    const output = await this.execGit(`log ${branch} --pretty=format:"${format}" --date=format:"%Y-%m-%d %H:%M" -n ${count}`);
    const commits = [];

    if (!output) return commits;

    const lines = output.split('\n').filter(line => line.trim());
    for (const line of lines) {
      const parts = line.split('|');
      if (parts.length >= 4) {
        commits.push({
          hash: parts[0].substring(0, 7),
          fullHash: parts[0],
          message: parts[1],
          author: parts[2],
          time: parts[3],
          refs: parts[4] || ''
        });
      }
    }
    return commits;
  }

  async getDiff(fileName, staged = false) {
    // 先检查文件是否是 untracked
    const isUntracked = await this.isUntracked(fileName);

    if (isUntracked) {
      // 对于新文件，直接显示完整内容
      try {
        const fullPath = path.join(this.repoPath, fileName);
        const content = fs.readFileSync(fullPath, 'utf8');
        const lines = content.split('\n');
        // 限制显示前 200 行，防止大文件卡死
        const limited = lines.slice(0, 200);
        const diff = limited.map(l => `+ ${l}`).join('\n');
        if (lines.length > 200) {
          return diff + `\n+ ... (${lines.length - 200} 行省略)`;
        }
        return diff;
      } catch (e) {
        return `+ 新文件: ${fileName}\n+ (无法读取文件内容: ${e.message})`;
      }
    }

    const cmd = staged ? `diff --staged -- "${fileName}"` : `diff -- "${fileName}"`;
    try {
      return await this.execGit(cmd);
    } catch (e) {
      return `+ 差异获取失败: ${e}`;
    }
  }

  async isUntracked(fileName) {
    try {
      const output = await this.execGit(`ls-files --others --exclude-standard -- "${fileName}"`);
      return output.trim() === fileName;
    } catch {
      return false;
    }
  }

  async stage(fileName) {
    return await this.execGit(`add -- "${fileName}"`);
  }

  async unstage(fileName) {
    return await this.execGit(`reset HEAD -- "${fileName}"`);
  }

  async stageAll() {
    return await this.execGit('add -A');
  }

  async unstageAll() {
    return await this.execGit('reset HEAD');
  }

  async commit(message) {
    // 使用 -m 时，将消息写入临时文件避免引号问题
    const tmpFile = path.join(this.repoPath, '.git', 'COMMIT_EDITMSG_GITCTRL');
    fs.writeFileSync(tmpFile, message, 'utf8');
    try {
      const result = await this.execGit(`commit -F "${tmpFile}"`);
      return result;
    } finally {
      try { fs.unlinkSync(tmpFile); } catch {}
    }
  }

  async push(branch) {
    if (branch) {
      return await this.execGit(`push origin "${branch}"`);
    }
    return await this.execGit('push');
  }

  async pull() {
    return await this.execGit('pull');
  }

  async fetch() {
    return await this.execGit('fetch');
  }

  async merge(branch) {
    return await this.execGit(`merge "${branch}"`);
  }

  async createBranch(name) {
    return await this.execGit(`branch "${name}"`);
  }

  async deleteBranch(name) {
    return await this.execGit(`branch -D "${name}"`);
  }

  async checkout(branch) {
    return await this.execGit(`checkout "${branch}"`);
  }

  async getCurrentBranch() {
    const output = await this.execGit('rev-parse --abbrev-ref HEAD');
    return output.trim();
  }
}

module.exports = GitService;
